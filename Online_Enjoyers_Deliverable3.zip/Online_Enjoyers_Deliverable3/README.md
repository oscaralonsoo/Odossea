# Odossea online - Sockets Deliverable 3

Equipo: Javier Gómez González, Mario Torrents Rodríguez, Toni Llovera Roca, Oscar Alonso Camenforte y David Subirats Bonet (CITM-UPC).

Odossea era un juego cooperativo local de dos jugadores. Para esta entrega lo hemos pasado a cooperativo online sobre UDP: un PC hace de host y juega con el Jugador 1, el otro se une como cliente y juega con el Jugador 2. Los dos ven a los dos jugadores moverse en su pantalla.

Repositorio: [ENLACE_AL_REPO](https://github.com/oscaralonsoo/Odossea)
Release con el .exe y el .unitypackage: [ENLACE_A_LA_RELEASE](https://github.com/oscaralonsoo/Odossea/releases/tag/Delivery_3)

## Cómo ejecutarlo

Se necesitan dos ordenadores en la misma red (o dos ventanas en el mismo PC, con la IP `127.0.0.1`).

1. Abrid el `.exe` en los dos PCs.
2. En el PC que hace de host: **Crear partida**. La sala queda abierta en el puerto UDP 9050.
3. En el otro PC: **Unirse**, poned un nombre, la IP del host (`ipconfig` en el host, la IPv4) y pulsad Unirse.
4. Cuando el cliente aparezca en la lista del host, el host pulsa **Start**. Los dos pasan a Level0.
5. Controles: los de siempre del juego (teclado o mando). Cada PC controla solo a su jugador.

Si no conecta, lo habitual es el firewall de Windows en el host (hay que permitir la aplicación en redes privadas, o el puerto UDP 9050 de entrada) o una red que no deja que los equipos se vean entre sí.

En el lobby hay también chat de texto, y el host puede expulsar a un jugador por nombre.

**Escena principal:** `MainMenu`. Desde ahí se llega a `S_CreateGame_UDP` (host), `S_JoinGame_UDP` (cliente) y a los niveles `Level0` y `Level1`.

Se ha desarrollado con Unity 6000.4.9f1. Si se abre con otra versión de Unity 6, Unity pedirá actualizar el proyecto.

## Qué se envía: estado, no input

Para el jugador enviamos **estado**, no input.

Nuestro jugador es un cuerpo blando de cinco huesos unidos con joints y fuerzas. Si cada PC simulara el mismo input, las dos físicas acabarían separándose en pocos segundos (no son deterministas), y cada PC vería una partida distinta. Así que cada PC simula solo a su propio jugador y manda la posición y el ángulo de sus cinco huesos unas 30 veces por segundo. El otro PC dibuja una copia que se mueve hacia el último estado recibido, con un suavizado para que no vaya a saltos. Si la copia queda a más de 4 unidades, se teletransporta (por ejemplo, al reaparecer). Cada mensaje incluye también el número de crecimiento, si el jugador está muerto, la animación (en el suelo, velocidad vertical) y la mira.

Cada jugador es dueño de su cuerpo, y el cliente no puede mover al jugador del host. El host, además, no se fía del índice de jugador que viene dentro del paquete y usa el del remitente real.

El mundo lo manda el **host**: las plataformas móviles y las puertas se simulan en el host y mandan su posición unas 15 veces por segundo (y una vez por segundo aunque no se muevan). El cliente apaga el script que las movería y copia lo que le llega.

## Mensajes y serialización

Todo lo que no es chat del lobby va en binario, con nuestro propio `Serializer` (`BinaryWriter` y `BinaryReader`). El primer byte de cada mensaje es el `MsgType`:

| MsgType | Contenido | Fiable |
|---|---|---|
| Text | texto del lobby | no |
| PlayerState | estado de los cinco huesos y datos del jugador | no |
| ObjectState | posición y ángulo de una plataforma o puerta | no |
| Event | disparo, cubo destruido, cambio de escena | sí |
| Ack | confirmación de un Event | no |

El lobby y el chat van como texto (`START:`, `READY:`, mensajes de chat...).

Los decimales de los mensajes de texto se escriben con `InvariantCulture`. Las hebras de red no tocan nada de Unity: solo meten los paquetes en una cola, y todo se procesa en `Update()`.

## Lag y fiabilidad

UDP no garantiza que los paquetes lleguen, ni en orden. Lo resolvemos así:

- **Posiciones: sin fiabilidad.** Si se pierde un paquete de estado, el siguiente llega 33 ms después con información más nueva, así que reenviar el antiguo no sirve. Cada mensaje lleva un número de secuencia (un `ushort` con vuelta) y se descarta cualquiera que sea más antiguo que el último recibido, así que un paquete que llega tarde no hace retroceder a un jugador.
- **Eventos: con fiabilidad.** Disparar un cubo, que un cubo desaparezca y cambiar de escena no pueden perderse. Cada evento lleva un identificador y se guarda hasta que el otro PC responde con un `Ack`; mientras tanto se reenvía cada 150 ms (hasta 60 intentos). El receptor recuerda los últimos 512 identificadores para no ejecutar dos veces un evento repetido, pero siempre vuelve a mandar el `Ack`, porque el anterior puede haberse perdido.
- **Conexión.** El host y el cliente comprueban con marcas de tiempo si el otro sigue ahí. Si uno se cae, el otro vuelve al menú con un aviso. El cliente aguanta hasta 10 s sin noticias del host para sobrevivir a una carga de escena.
- **Lag percibido.** Cada PC ve a su propio jugador sin retraso, y al otro con el retraso de la red más el suavizado. No hay predicción ni compensación: a cambio es simple y no se desincroniza.

## Escenas

Solo el host decide cuándo se cambia de escena. Si el cliente toca la meta o pide reiniciar, manda una `SceneRequest` al host, y el host responde con un `SceneLoad` a los dos. Así los dos terminan siempre en el mismo nivel. Esto está en `GameNet` y se engancha en `SceneTransitionManager.LoadScene`.

## Extras hechos

- **Movimiento completo:** los cinco huesos, el salto, el crecimiento, la muerte y reaparición, la animación y la mira.
- **Disparar y absorber cubos de masa:** el disparo aparece en el otro PC, y cuando un cubo se absorbe o se fusiona desaparece en los dos.
- **Partida completa:** se juega Level0 y Level1 con cambio de nivel y reinicio sincronizados.
- **Lobby:** chat, expulsar jugadores y botón Start del host.

No hemos hecho más de dos jugadores: el juego tiene solo los prefabs `Player1` y `Player2`, y el lobby está limitado a 2.

## Bugs conocidos

- Máximo dos jugadores.
- Los *crushers* (aplastadores) no están sincronizados: cada PC ejecuta su propio ciclo y solo mata al jugador de su PC, así que pueden verse en momentos distintos.
- La pausa (`Time.timeScale`) solo congela el PC que pausa: el otro sigue jugando.
- Si el host se cierra mientras el cliente carga una escena, el cliente tarda hasta 10 s en darse cuenta.
- Con mucha pérdida de paquetes, el otro jugador se ve a saltos.
- (Añadid aquí cualquier otro fallo que encontréis en la prueba entre dos PCs, y quitad los que no se den.)

## Cambios desde la entrega 2

- El lobby pasa a ser solo UDP (la entrega 2 tenía TCP y UDP), y se mueve a Odossea: `SocketsUDPServer` y `SocketsUDPClient`, con el índice de jugador (host = 0, cliente = 1).
- Handshake de inicio: el host manda `START` una vez por segundo hasta que el cliente responde `READY`, para no perder el aviso de inicio.
- Nuevo `Serializer` con byte `MsgType` y un canal de eventos fiables sobre UDP (`ReliableChannel`).
- Nuevos scripts de juego: `GameNet`, `NetPlayerSync`, `NetObjectSync`, `NetWorld`, `NetCube`.
- Cambios mínimos en el código de Odossea: `PlayerController`, `CubeTrigger`, `MassCubeInstantiator`, `DropableCube` y `SceneTransitionManager`.
- Eliminado el código del Lab 3 y del Lobby antiguo que ya no se usaba.

## Reparto del trabajo

Hemos repartido la red en cinco bloques de tamaño parecido. Todos hemos participado en las pruebas entre dos PCs y en el vídeo, y todos sabemos explicar el código de red completo.

| Miembro | Trabajo |
|---|---|
| Javier Gómez González | Lobby UDP (`SocketsUDPServer`, `SocketsUDPClient`, `LobbyPlayer`): sala, chat, expulsar, handshake `START`/`READY`. Botones y escenas de menú, build, Release, README. |
| Mario Torrents Rodríguez | Serialización: `Serializer`, `MsgType` y los mensajes (`PlayerStateDTO`, `ObjectStateDTO`, `GameEventDTO`). Pruebas de ida y vuelta de los mensajes. |
| Toni Llovera Roca | Transporte: `NetLink`, `NetUtil`, `NetPacket`, hebras de recepción con cola y procesado en `Update()`, comprobación de caídas. `ReliableChannel`: Ack, reenvíos y descarte de repetidos. |
| Oscar Alonso Camenforte | Sincronización del jugador: `NetPlayerSync` (estado de los cinco huesos, copia remota, suavizado) y los cambios en `PlayerController` y `CubeTrigger`. |
| David Subirats Bonet | Mundo y eventos: `GameNet` y cambios de escena por el host (`SceneTransitionManager`), `NetObjectSync` y `NetWorld` (plataformas y puertas), cubos de masa (`NetCube`, `MassCubeInstantiator`, `DropableCube`). |